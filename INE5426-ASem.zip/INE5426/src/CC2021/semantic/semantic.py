# analisador semantico

from CC2021.semantic.yacc_builder import parse


def semantic_parse(data):
    return parse(data)